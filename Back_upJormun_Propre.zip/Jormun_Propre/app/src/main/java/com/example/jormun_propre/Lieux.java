package com.example.jormun_propre;

public class Lieux
{
    int PosX;
    int PosY;
    int Type;
    String Nom;
    public Lieux(int VPosX, int VPosY, int VType, String VNom)
    {
        this.PosX = VPosX;
        this.PosY = VPosY;
        this.Type = VType;
        this.Nom = VNom;
    }
}
